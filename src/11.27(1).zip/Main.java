import java.util.ArrayList;
import java.util.Scanner;
import java.time.LocalDate; // 需要导入这个

public class Main {
    // 文件路径
    private static final String MOVIES_FILE = "data/movies.csv";
    private static final String USERS_FILE = "data/users.csv";

    // 数据存储
    private static ArrayList<Movie> allMovies;
    private static ArrayList<User> allUsers;
    private static User currentUser = null;

    // 文件处理器
    private static MovieFileHandler movieHandler = new MovieFileHandler();
    private static UserFileHandler userHandler = new UserFileHandler();

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Welcome to Movie Recommendation System ===");
        System.out.println("Loading data...");

        allMovies = movieHandler.loadMovies(MOVIES_FILE);
        allUsers = userHandler.loadUsers(USERS_FILE);

        if (allMovies.isEmpty() || allUsers.isEmpty()) {
            System.out.println("Error: Failed to load data. Please check your data files.");
            return;
        }

        boolean running = true;
        while (running) {
            if (currentUser == null) {
                running = showLoginMenu();
            } else {
                running = showMainMenu();
            }
        }

        System.out.println("Saving data...");
        userHandler.saveUsers(USERS_FILE, allUsers);
        System.out.println("Thank you for using Movie Recommendation System!");
        scanner.close();
    }

    private static boolean showLoginMenu() {
        System.out.println("\n=== Login Menu ===");
        System.out.println("1. Login");
        System.out.println("2. Exit");
        System.out.print("Please select an option: ");

        try {
            String input = scanner.nextLine().trim();
            // 防止空输入报错
            if(input.isEmpty()) return true;
            int choice = Integer.parseInt(input);

            switch (choice) {
                case 1: login(); break;
                case 2: return false;
                default: System.out.println("Invalid option.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
        }
        return true;
    }

    private static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter password: ");
        String password = scanner.nextLine().trim();

        User user = userHandler.findUserByUsername(allUsers, username);

        if (user != null && user.verifyPassword(password)) {
            currentUser = user;
            System.out.println("Login successful! Welcome, " + username + "!");
        } else {
            System.out.println("Login failed. Invalid username or password.");
        }
    }

    private static boolean showMainMenu() {
        System.out.println("\n=== Main Menu ===");
        System.out.println("1. Browse movies");
        System.out.println("2. Add movie to watchlist");
        System.out.println("3. Remove movie from watchlist");
        System.out.println("4. View watchlist");
        System.out.println("5. Mark movie as watched");
        System.out.println("6. View history");
        System.out.println("7. Get recommendations");
        System.out.println("8. Logout");
        System.out.print("Please select an option: ");

        try {
            String input = scanner.nextLine().trim();
            if(input.isEmpty()) return true;
            int choice = Integer.parseInt(input);

            switch (choice) {
                case 1: browseMovies(); break;
                case 2: addToWatchlist(); break;
                case 3: removeFromWatchlist(); break;
                case 4: viewWatchlist(); break;
                case 5: markAsWatched(); break;
                case 6: viewHistory(); break;
                case 7: getRecommendations(); break;
                case 8: logout(); break;
                default: System.out.println("Invalid option.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input.");
        }
        return true;
    }

    private static void browseMovies() {
        System.out.println("\n=== All Movies ===");
        for (Movie movie : allMovies) {
            System.out.println(movie);
        }
    }

    private static void addToWatchlist() {
        System.out.print("Enter movie ID to add to watchlist (e.g., M001): ");
        try {
            String movieId = scanner.nextLine().trim();
            Movie movie = movieHandler.findMovieById(allMovies, movieId);

            if (movie == null) {
                System.out.println("Movie not found.");
            } else if (currentUser.getWatchlist().contains(movieId)) {
                System.out.println("Movie already in your watchlist.");
            } else {
                // Fix: 删除了 else if (watched) 检查，允许二刷
                currentUser.addToWatchlist(movieId);
                System.out.println("Added '" + movie.getTitle() + "' to your watchlist.");
                // Fix: 实时保存
                userHandler.saveUsers(USERS_FILE, allUsers);
            }
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }

    private static void removeFromWatchlist() {
        if (currentUser.getWatchlist().isEmpty()) {
            System.out.println("Your watchlist is empty.");
            return;
        }
        viewWatchlist();
        System.out.print("Enter movie ID to remove: ");
        try {
            String movieId = scanner.nextLine().trim();
            if (currentUser.getWatchlist().contains(movieId)) {
                currentUser.removeFromWatchlist(movieId);
                System.out.println("Removed movie.");
                // Fix: 实时保存
                userHandler.saveUsers(USERS_FILE, allUsers);
            } else {
                System.out.println("Movie not in watchlist.");
            }
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }

    private static void viewWatchlist() {
        System.out.println("\n=== Your Watchlist ===");
        if (currentUser.getWatchlist().isEmpty()) {
            System.out.println("Your watchlist is empty.");
        } else {
            for (String movieId : currentUser.getWatchlist()) {
                Movie movie = movieHandler.findMovieById(allMovies, movieId);
                if (movie != null) System.out.println(movie);
            }
        }
    }

    private static void markAsWatched() {
        System.out.print("Enter movie ID to mark as watched: ");
        try {
            String movieId = scanner.nextLine().trim();
            Movie movie = movieHandler.findMovieById(allMovies, movieId);

            if (movie == null) {
                System.out.println("Movie not found.");
            } else {
                String currentDate = LocalDate.now().toString();
                currentUser.addToHistory(movieId, currentDate);
                System.out.println("Marked '" + movie.getTitle() + "' as watched.");
                // Fix: 实时保存
                userHandler.saveUsers(USERS_FILE, allUsers);
            }
        } catch (Exception e) {
            System.out.println("Invalid input.");
        }
    }

    private static void viewHistory() {
        System.out.println("\n=== Your Watch History ===");
        if (currentUser.getHistory().isEmpty()) {
            System.out.println("No history yet.");
        } else {
            for (String entry : currentUser.getHistory()) {
                String[] parts = entry.split("@");
                if (parts.length == 2) {
                    Movie movie = movieHandler.findMovieById(allMovies, parts[0]);
                    if (movie != null) {
                        System.out.println(movie + " | Watched: " + parts[1]);
                    }
                }
            }
        }
    }

    private static void getRecommendations() {
        System.out.print("How many recommendations do you want? ");
        try {
            String input = scanner.nextLine().trim();
            if(input.isEmpty()) return;
            int n = Integer.parseInt(input);
            if (n <= 0) {
                System.out.println("Please enter a positive number.");
                return;
            }

            // Fix: 使用正确的类名 RecommendationEngine
            RecommendationEngine engine = new RecommendationEngine(allMovies);
            // Fix: 接收 ArrayList<MovieScore> 而不是 Movie
            ArrayList<RecommendationEngine.MovieScore> recommendations = engine.getRecommendations(currentUser, n);

            System.out.println("\n=== Recommended Movies for You ===");
            if (recommendations.isEmpty()) {
                System.out.println("No recommendations available.");
            } else {
                for (RecommendationEngine.MovieScore ms : recommendations) {
                    // Fix: 打印电影信息 + 算法计算出的分数
                    // 分数 x10 转换成 10分制显示，保留1位小数
                    double displayScore = ms.score * 10.0;
                    System.out.println(String.format("[Score: %.2f] %s", displayScore, ms.movie.toString()));
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input.");
        }
    }

    private static void logout() {
        System.out.println("Logging out! Goodbye, " + currentUser.getUsername() + "!");
        currentUser = null;
    }
}